```
#include <stdio.h>
#include <cs50.h>

int main(void)
{
    //this gets users input
    string name = get_string("What's your name? ");
    //this give you the users input and adds the stuff you told it to:
    printf("hello, %s\n", name);
}
```
