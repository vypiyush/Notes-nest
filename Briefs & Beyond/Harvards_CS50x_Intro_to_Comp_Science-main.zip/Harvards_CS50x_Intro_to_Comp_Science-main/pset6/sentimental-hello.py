# I don't need a main
answer = input("What's your name? ")
print(f"hello, {answer}")
