## Scheduled mongodb backup using nodejs

The relevant comments are inside the `app.js` file
